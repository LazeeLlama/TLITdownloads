
function PrintError ($message) {
   Write-Host $message -ForegroundColor Red -BackgroundColor Black
}

function AddVPNConnection () {
  try {
    Add-VpnConnection -Name 'Tolland IKEv2' -ServerAddress '50.77.28.17' -TunnelType 'IKEv2' -EncryptionLevel 'Required' -AuthenticationMethod Eap  -RememberCredential 
    Set-VpnConnectionIPsecConfiguration -ConnectionName 'Tolland IKEv2' -AuthenticationTransformConstants 'SHA196' -CipherTransformConstants 'AES256' -DHGroup 'Group14' -EncryptionMethod 'AES256' -IntegrityCheckMethod 'SHA256' -PfsGroup 'None' -Force
    Write-Host "Created the 'Tolland IKEv2' VPN connection"
  }   catch {
    PrintError "Error in creating the 'Tolland IKEv2' VPN connection!" 
    PrintError $_.Exception.Message
  }
}

$vpn = Get-VpnConnection -Name 'Tolland IKEv2' -ErrorAction SilentlyContinue
if ($vpn -and ($vpn.Name -eq 'Tolland IKEv2')) {
  PrintError "A VPN connection with the name 'Tolland IKEv2' is already configured on your system."
  $message = "Do you want to update the existing 'Tolland IKEv2' VPN connection?"
  $yes = New-Object System.Management.Automation.Host.ChoiceDescription "&Yes", "Updates the 'Tolland IKEv2' VPN connection."
  $no = New-Object System.Management.Automation.Host.ChoiceDescription "&No", "Exit without updating."
  $options = [System.Management.Automation.Host.ChoiceDescription[]]($yes, $no)
  $result = $host.ui.PromptForChoice('', $message, $options, 0)
  switch ($result) {
    0 {Remove-VpnConnection -Name 'Tolland IKEv2' -Force}
    1 {
      PrintError "The existing �Tolland IKEv2� VPN connection was not updated. Remove or rename the existing VPN connection and run the script again.";
      exit
    }
  }
}

AddVPNConnection
exit

