Configure an IKEv2 VPN Connection to a WatchGuard Firebox in macOS or iOS
=========================================================================
In the same folder as this README file, find the "Tolland IKEv2.mobileconfig" file. On your Apple device, you can import this profile to automatically create a new IKEv2 VPN profile. This profile includes the required CA certificate. 

You can also manually configure an IKEv2 VPN connection. This README file includes instructions for both automatic and manual configuration.

For operating system support information, see the Operating System Compatibility Matrix in the Fireware Release Notes at https://www.watchguard.com/wgrd-help/documentation/release-notes/fireware.

=========================================================================
Automatic Configuration for macOS and iOS

To automatically add a new IKEv2 VPN profile in macOS:

    1. Send the .mobileconfig file to your macOS computer.
    2. To import the .mobileconfig file, double-click it. A "Profile Installation" message appears.
    3. Select "System Preferences" > "Profiles."
    4. In the Profiles window, select the client profile
    5. Click "Install."
    6. When prompted to install the profile, click "Install." 
    7. From the Apple menu, select "System Preferences" > "Network."
    8. To connect to the VPN, click the VPN connection that you added and click "Connect."

To automatically add a new IKEv2 VPN profile in iOS:

    1. Send the .mobileconfig file to your iOS device.
    2. Open the message in the native iOS mail app and tap the .mobileconfig file. A “Profile Downloaded” message appears.
    3. Open the profile:
       (iOS 15) Tap "Settings" > "General" > "VPN & Device Management"
       (iOS 14) Tap "Settings" > "General" > "Profile."
    4. In the "Downloaded Profile" section, tap the profile.
    5. Tap "Install" > "Next" > "Install" > "Install."
    6. (Required) Specify the username and password. 
    Note: On iOS devices, if you do not specify credentials in the configuration, the VPN profile exists but fails to connect.
    7. Tap "Done."
    8. On the "Settings" screen, tap "VPN."
    9. To connect to the VPN, tap the VPN connection that you added.
    10. Slide the "Status" toggle to "Connecting."

=========================================================================
Manual Configuration for macOS and iOS

To manually add a new IKEv2 VPN connection in macOS:

    1. Send the .CRT or .PEM certificate file to your macOS computer.
    2. To install the certificate, click it. The Keychain Access application opens.
    3. Add the certificate to the existing list.
    4. Find the certificate in the list and double-click it. 
    5. Expand the "Trust" menu. Change "When using this certificate" to "Always Trust."
    6. From the Apple menu, select "System Preferences" > "Network." 
    7. To add a new service, click the + symbol. 
    8. To configure the VPN, specify these settings:
        Interface: "VPN"
        VPN Type: "IKEv2"
        Service Name: [Descriptive name such as "MyCompany IKEv2 VPN"]
    9. Click "Create." 
    10. On the next screen, specify these settings:
        Server Address: 50.77.28.17
        Remote ID: 50.77.28.17
    11. Click "Authentication Settings" and specify the user information:
        Authentication Settings: "Username"
        Username: [Your mobile VPN username]
        Password: (Optional) To save your password for later use, specify it now. 
    12. Click "OK" and then click "Apply." 
    13. To connect to the VPN, from the Apple menu, select "System Preferences" > "Network."
    14. Click the VPN connection you added and click "Connect."

To manually add a new IKEv2 VPN connection in iOS:

    1. Send the .CRT or .PEM certificate file to your iOS device.
    2. Open the message in the native iOS mail app.
    3. To install the certificate, tap it. A "Profile Downloaded" message appears.
    4. (iOS 15) Tap "Settings" > "Profile Downloaded" > "Install" > "Install" > "Done."
    5. Add a VPN Configuration:
       (iOS 15) Tap "Settings" > "General" > "VPN & Device Management" > "VPN"
       (iOS 14) Tap "Settings" > "VPN."
    6. Click "Add VPN Configuration."
    7. To configure the VPN, specify these settings:
        Type: "IKEv2"
        Description: [Descriptive name such as "MyCompany IKEv2 VPN"]
        Server: 50.77.28.17
        Remote ID: 50.77.28.17
        User Authentication: "Username"
        Username: [Your mobile VPN username]
        Password: [Your mobile VPN password]
        Note: On iOS devices, if you do not specify credentials in the configuration, the VPN profile exists but fails to connect.
    8. Tap "Done."
    9. To connect to the VPN, on the VPN screen, slide the "Status" toggle to "Connecting."
    
=========================================================================
WatchGuard provides interoperability instructions to help our customers configure WatchGuard products to work with products created by other organizations. If you need more information or technical support about configuring a non-WatchGuard product, see the documentation and support resources for that product. 
=========================================================================
