Configure an IKEv2 VPN Connection to a WatchGuard Firebox
=========================================================
You can use the files in this package to automatically create a new IKEv2 VPN profile on devices with supported versions of Windows, macOS, iOS, Android, or the WatchGuard IPSec Mobile VPN Client for Windows application. You can also manually configure an IKEv2 VPN profile on your device. If you manually configure a VPN profile, you must install the .PEM or .CRT certificate included in the same folder as this README file.

For configuration instructions specific to your operating system, go to the README.txt files in these folders:
* Windows
* MacOS_iOS
* Android
* WatchGuard IPSec Mobile VPN Client

For information on operating system support, go to the Operating System Compatibility Matrix in the Fireware Release Notes at https://www.watchguard.com/wgrd-help/documentation/release-notes/fireware.

For online versions of IKEv2 VPN client configuration instructions, go to these topics in Fireware Help:

Windows Devices:
https://www.watchguard.com/help/docs/help-center/en-US/Content/en-US/Fireware/mvpn/ikev2/mvpn_ikev2_windows_client.html

macOS and iOS Devices: 
https://www.watchguard.com/help/docs/help-center/en-US/Content/en-US/Fireware/mvpn/ikev2/mvpn_ikev2_mac_client.html

Android Devices (with the strongSwan app): 
https://www.watchguard.com/help/docs/help-center/en-US/Content/en-US/Fireware/mvpn/ikev2/mvpn_ikev2_android_client.html

WatchGuard IPSec Mobile VPN Client:
https://www.watchguard.com/help/docs/help-center/en-US/Content/en-US/Fireware/mvpn/ikev2/mvpn_ikev2_mobile_vpn_client.html

=========================================================
WatchGuard provides interoperability instructions to help our customers configure WatchGuard products to work with products created by other organizations. If you need more information or technical support about configuring a non-WatchGuard product, see the documentation and support resources for that product. 
=========================================================
