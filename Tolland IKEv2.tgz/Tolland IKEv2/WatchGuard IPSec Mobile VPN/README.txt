Configure an IKEv2 VPN Connection Profile with the WatchGuard IPSec Mobile VPN Client
=====================================================================================

This README file includes instructions about the import of an automatic IKEv2 VPN profile.

The "WG IKEv2 \ WatchGuard IPSec Mobile VPN" directory that contains this README file also contains an .INI profile configuration file and a .PEM certificate file. You can use these files with the WatchGuard IPSec Mobile VPN Client for Windows to create and configure an IKEv2 profile for a Windows host computer.  

Note: The WatchGuard IPSec Mobile VPN Client for macOS does not support IKEv2.

=====================================================================================

To import an IKEv2 VPN profile to the IPSec Mobile VPN client, from the Windows host computer:

    1. Download the WatchGuard IPSec Mobile VPN Client for Windows from the Software Downloads section of the WatchGuard website (https://software.watchguard.com/).

    2. Install the IPSec Mobile VPN client. When the installation wizard completes, restart the computer.

    3. From the "WG IKEv2 \ WatchGuard IPSec Mobile VPN" directory, copy the .PEM file to this location on the Windows host computer: 
       C:\ProgramData\WatchGuard\Mobile VPN\cacerts

    4. From the Windows host computer, select "Start > WatchGuard Mobile VPN > Mobile VPN Monitor".

    5. If the IPSec Mobile VPN client prompts you to manually configure a profile, click "No". 

    6. Select "Configuration > Profiles".
       The Profiles page opens.

    7. Click "Add / Import".
       The New Profile Wizard starts.

    8. From the "Connection Type" page, select "Profile Import".

    9. Click "Next".
       The Select User Profile page opens.

   10. From "File Name," browse to the "WG IKEv2 \ WatchGuard IPSec Mobile VPN" directory, select the .INI configuration file, and click "Open". 
       Note: To view the .INI file, select "All Files" from the Windows file format drop-down list.

   11. Click "Next".
       The Overwrite or Add Profile page opens.

   12. Select the profile to import.

   13. Click "Next", and click "Finish".
      The new profile is now available as a connection profile.

====================================================================
WatchGuard provides interoperability instructions to help our customers configure WatchGuard products to work with products created by other organizations. If you need more information or technical support about configuring a non-WatchGuard product, see the documentation and support resources for that product. 
====================================================================
